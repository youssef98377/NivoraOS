#!/usr/bin/env bash
# Step 0: verify the build machine has what we need. Changes nothing.
source "$(dirname "$0")/lib.sh"
missing=0
for t in curl sha256sum xorriso unsquashfs mksquashfs chroot gpgv; do
  if command -v "$t" >/dev/null; then log "found: $t"; else warn "missing: $t"; missing=1; fi
done
command -v qemu-system-i386 >/dev/null && log "found: qemu-system-i386 (boot test possible)" || warn "qemu-system-i386 missing: boot test will be skipped"
log "machine: $(uname -m), free space in $WORK_DIR:"
df -h "$WORK_DIR" | tail -1
free_gb=$(df -BG --output=avail "$WORK_DIR" | tail -1 | tr -dc '0-9')
[ "${free_gb:-0}" -ge 14 ] || die "Need at least 14 GB free disk space (found ${free_gb} GB)."
[ "$missing" -eq 0 ] || die "Install missing tools: sudo apt-get install -y curl coreutils xorriso squashfs-tools gpgv qemu-system-x86"
log "Environment OK"
