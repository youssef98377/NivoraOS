#!/usr/bin/env bash
# Shared helpers for all Nivora build scripts.
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORK_DIR="${WORK_DIR:-$ROOT_DIR/work}"
DIST_DIR="${DIST_DIR:-$ROOT_DIR/dist}"
LOG_DIR="${LOG_DIR:-$ROOT_DIR/logs}"
mkdir -p "$WORK_DIR" "$DIST_DIR" "$LOG_DIR"

# shellcheck disable=SC1091
source "$ROOT_DIR/config/antix.env"

log()  { printf '[%s] %s\n' "$(date -u +%H:%M:%S)" "$*"; }
warn() { printf '[%s] WARNING: %s\n' "$(date -u +%H:%M:%S)" "$*" >&2; }
die()  { printf '[%s] ERROR: %s\n' "$(date -u +%H:%M:%S)" "$*" >&2; exit 1; }

need_cmd() { command -v "$1" >/dev/null 2>&1 || die "Missing tool: $1 (install it first, see scripts/00-check-env.sh)"; }
need_root() { [ "$(id -u)" -eq 0 ] || die "This step must run as root (use sudo)."; }
