#!/usr/bin/env bash
# Step 2: pull the live filesystem out of the ISO and unpack it. Needs root (squashfs owners).
source "$(dirname "$0")/lib.sh"
need_root; need_cmd xorriso; need_cmd unsquashfs
ISO="$WORK_DIR/download/$ANTIX_ISO_NAME"
[ -f "$ISO" ] || die "Base ISO missing; run scripts/10-fetch-verify.sh first"

log "Listing ISO layout (saved to logs/base-iso-files.txt)"
xorriso -indev "$ISO" -find / -type f 2>/dev/null > "$LOG_DIR/base-iso-files.txt" || die "Cannot read ISO"

# antiX keeps the compressed root filesystem at /antiX/linuxfs
grep -q "'/antiX/linuxfs'" "$LOG_DIR/base-iso-files.txt" || die "/antiX/linuxfs not found in the ISO: antiX layout changed, review the scripts."

rm -rf "$WORK_DIR/linuxfs.orig" "$WORK_DIR/rootfs"
log "Extracting /antiX/linuxfs"
xorriso -osirrox on -indev "$ISO" -extract /antiX/linuxfs "$WORK_DIR/linuxfs.orig" 2>&1 | tail -2
[ -s "$WORK_DIR/linuxfs.orig" ] || die "Extracted linuxfs is empty"

unsquashfs -s "$WORK_DIR/linuxfs.orig" | tee "$LOG_DIR/base-squashfs-info.txt" | sed -n '1,12p'
log "Unpacking root filesystem (several GB, a few minutes)"
unsquashfs -f -d "$WORK_DIR/rootfs" "$WORK_DIR/linuxfs.orig" >/dev/null
[ -x "$WORK_DIR/rootfs/bin/sh" ] || [ -L "$WORK_DIR/rootfs/bin" ] || die "Unpacked rootfs looks wrong"
grep -E '^(NAME|VERSION|PRETTY_NAME)=' "$WORK_DIR/rootfs/etc/os-release" | tee "$LOG_DIR/base-os-release.txt" || true
ls "$WORK_DIR/rootfs/lib/modules" 2>/dev/null | tee "$LOG_DIR/base-kernels.txt" || true
log "Extract done"
