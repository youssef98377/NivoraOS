#!/usr/bin/env bash
# Runs INSIDE the chroot. Do not run on a real machine.
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
cd /tmp/nivora
# shellcheck disable=SC1091
source flags.env

strip_comments() { grep -vE '^\s*(#|$)' "$1" || true; }


# Installing a package must NEVER remove another package: antiX diverts desktop files of its own
# packages, and removing one (e.g. inxi-gui-antix, claws-mail) makes the desktop ask for an admin
# password at boot (seen in QEMU screenshots of builds 0.1.2 and 0.1.3).
# safe_install simulates first (apt-get -s) and refuses if anything would be removed.
safe_install() {
  local removed
  removed=$(apt-get -s -y --no-install-recommends install "$@" 2>&1 | grep -E '^Remv ' || true)
  if [ -n "$removed" ]; then
    echo "REFUSED: installing '$*' would REMOVE base packages:"; echo "$removed"
    return 3
  fi
  apt-get -y --no-install-recommends install "$@"
}

purge_matching() {
  local pat pkgs
  while read -r pat; do
    pkgs=$(dpkg-query -W -f='${db:Status-Abbrev} ${Package}\n' "$pat" 2>/dev/null | awk '$1 ~ /^ii/ {print $2}' || true)
    if [ -n "$pkgs" ]; then
      echo "purging: $(echo "$pkgs" | wc -l) packages for pattern $pat"
      # shellcheck disable=SC2086
      apt-get -y purge $pkgs
    else
      echo "nothing installed for pattern: $pat"
    fi
  done < <(strip_comments "$1")
}

echo "== apt update"
apt-get update

if [ "${PURGE_HEAVY:-0}" = "1" ]; then
  echo "== removing heavy packages (PURGE_HEAVY=1)"
  purge_matching packages-remove.txt
  if [ "$INCLUDE_BROWSER" = "0" ]; then purge_matching packages-remove-browser.txt; fi
else
  echo "== NOT removing any base packages (PURGE_HEAVY=0)"
fi

echo "== installing REQUIRED packages"
# shellcheck disable=SC2046
safe_install $(strip_comments packages-required.txt)

echo "== installing OPTIONAL packages (one by one)"
while read -r line; do
  if [[ "$line" == any:* ]]; then
    done_any=0
    for p in ${line#any:}; do
      if safe_install "$p"; then echo "ok (any-of): $p"; done_any=1; break; else echo "WARNING: any-of candidate failed: $p"; fi
    done
    [ "$done_any" = 1 ] || echo "WARNING: none of the any-of candidates installed: ${line#any:}"
  else
    if safe_install "$line"; then echo "ok: $line"; else echo "WARNING: could not install optional package $line"; fi
  fi
done < <(strip_comments packages-optional.txt)

echo "== locales (Arabic + English)"
if [ -f /etc/locale.gen ]; then
  sed -i 's/^# *\(ar_EG.UTF-8\)/\1/; s/^# *\(en_US.UTF-8\)/\1/' /etc/locale.gen
  command -v locale-gen >/dev/null && locale-gen || echo "WARNING: locale-gen not available"
fi

echo "== keyboard layout default: US + Arabic, Alt+Shift to switch"
if [ -f /etc/default/keyboard ]; then
  sed -i 's/^XKBLAYOUT=.*/XKBLAYOUT="us,ara"/; s/^XKBOPTIONS=.*/XKBOPTIONS="grp:alt_shift_toggle"/' /etc/default/keyboard
fi

echo "== cleanup"
apt-get clean
rm -rf /var/lib/apt/lists/* /var/cache/apt/*.bin
echo "chroot customization finished OK"
