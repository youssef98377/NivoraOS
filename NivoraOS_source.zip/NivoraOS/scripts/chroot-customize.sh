#!/usr/bin/env bash
# Runs INSIDE the chroot. Do not run on a real machine.
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
cd /tmp/nivora
# shellcheck disable=SC1091
source flags.env

strip_comments() { grep -vE '^\s*(#|$)' "$1" || true; }

purge_matching() {
  local pat pkgs
  while read -r pat; do
    pkgs=$(dpkg-query -W -f='${db:Status-Abbrev} ${Package}\n' "$pat" 2>/dev/null | awk '$1 ~ /^ii/ {print $2}' || true)
    if [ -n "$pkgs" ]; then
      echo "purging: $(echo "$pkgs" | wc -l) packages for pattern $pat"
      # shellcheck disable=SC2086
      apt-get -y purge $pkgs
    else
      echo "nothing installed for pattern: $pat"
    fi
  done < <(strip_comments "$1")
}

echo "== apt update"
apt-get update

echo "== removing heavy packages"
purge_matching packages-remove.txt
[ "$INCLUDE_BROWSER" = "0" ] && purge_matching packages-remove-browser.txt

echo "== installing REQUIRED packages"
# shellcheck disable=SC2046
apt-get -y --no-install-recommends install $(strip_comments packages-required.txt)

echo "== installing OPTIONAL packages (one by one)"
while read -r p; do
  if apt-get -y --no-install-recommends install "$p"; then echo "ok: $p"; else echo "WARNING: could not install optional package $p"; fi
done < <(strip_comments packages-optional.txt)

echo "== locales (Arabic + English)"
if [ -f /etc/locale.gen ]; then
  sed -i 's/^# *\(ar_EG.UTF-8\)/\1/; s/^# *\(en_US.UTF-8\)/\1/' /etc/locale.gen
  command -v locale-gen >/dev/null && locale-gen || echo "WARNING: locale-gen not available"
fi

echo "== keyboard layout default: US + Arabic, Alt+Shift to switch"
if [ -f /etc/default/keyboard ]; then
  sed -i 's/^XKBLAYOUT=.*/XKBLAYOUT="us,ara"/; s/^XKBOPTIONS=.*/XKBOPTIONS="grp:alt_shift_toggle"/' /etc/default/keyboard
fi

echo "== cleanup"
apt-get clean
rm -rf /var/lib/apt/lists/* /var/cache/apt/*.bin
echo "chroot customization finished OK"
