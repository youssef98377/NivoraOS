#!/usr/bin/env bash
# Step 1: download the official antiX ISO and verify its SHA-256. Fails hard on mismatch.
source "$(dirname "$0")/lib.sh"
need_cmd curl; need_cmd sha256sum
DL="$WORK_DIR/download"; mkdir -p "$DL"
ISO="$DL/$ANTIX_ISO_NAME"

check() { echo "$ANTIX_ISO_SHA256  $ISO" | sha256sum -c - >/dev/null 2>&1; }

if [ -f "$ISO" ] && check; then
  log "ISO already downloaded and hash matches."
else
  log "Downloading $ANTIX_ISO_NAME (about 2.3 GB) from the official antiX SourceForge project..."
  rm -f "$ISO"
  curl -fL --retry 5 --retry-delay 10 -o "$ISO" "$ANTIX_ISO_URL"
  check || { rm -f "$ISO"; die "SHA-256 MISMATCH for $ANTIX_ISO_NAME. Download deleted. Do not use this file."; }
fi
log "SHA-256 verified OK: $ANTIX_ISO_SHA256"
echo "$ANTIX_ISO_SHA256  $ANTIX_ISO_NAME" > "$DL/base-iso.sha256"

# Optional GPG signature check: needs the antiX public key in a keyring file.
SIG="$DL/$ANTIX_ISO_NAME.sig"
if [ -n "${ANTIX_GPG_KEYRING:-}" ] && [ -f "$ANTIX_GPG_KEYRING" ]; then
  curl -fL --retry 3 -o "$SIG" "$ANTIX_SIG_URL"
  gpgv --keyring "$ANTIX_GPG_KEYRING" "$SIG" "$ISO" && echo "gpg: VERIFIED" > "$DL/gpg-status.txt" \
    || die "GPG signature check FAILED"
else
  echo "gpg: NOT VERIFIED (no keyring provided; SHA-256 from official page was verified)" > "$DL/gpg-status.txt"
  warn "$(cat "$DL/gpg-status.txt")"
fi
