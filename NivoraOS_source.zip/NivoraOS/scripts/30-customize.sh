#!/usr/bin/env bash
# Step 3: apply Nivora changes inside the unpacked system (chroot). Needs root + network (apt).
source "$(dirname "$0")/lib.sh"
need_root
R="$WORK_DIR/rootfs"
[ -d "$R/etc" ] || die "rootfs missing; run scripts/20-extract.sh first"

cleanup() {
  for m in dev/pts dev proc sys; do mountpoint -q "$R/$m" && umount -l "$R/$m" || true; done
  rm -f "$R/usr/sbin/policy-rc.d"
}
trap cleanup EXIT

mount -t proc proc "$R/proc"; mount --rbind /sys "$R/sys"; mount --rbind /dev "$R/dev"
# Temporary DNS for apt inside the chroot (original restored at the end)
if [ -e "$R/etc/resolv.conf" ] || [ -L "$R/etc/resolv.conf" ]; then mv "$R/etc/resolv.conf" "$R/etc/resolv.conf.orig-antix"; fi
cp -L /etc/resolv.conf "$R/etc/resolv.conf"
printf '#!/bin/sh\nexit 101\n' > "$R/usr/sbin/policy-rc.d"; chmod +x "$R/usr/sbin/policy-rc.d"

# Hand package lists + flags to the chroot script
mkdir -p "$R/tmp/nivora"
cp "$ROOT_DIR"/config/packages-*.txt "$R/tmp/nivora/"
cp "$ROOT_DIR/scripts/chroot-customize.sh" "$R/tmp/nivora/"
printf "INCLUDE_BROWSER=%s\nPURGE_HEAVY=%s\n" "$INCLUDE_BROWSER" "$PURGE_HEAVY" > "$R/tmp/nivora/flags.env"

log "Running package changes inside the 32-bit system"
chroot "$R" /bin/bash /tmp/nivora/chroot-customize.sh 2>&1 | tee "$LOG_DIR/chroot-customize.log"
[ "${PIPESTATUS[0]}" -eq 0 ] || die "chroot customization failed (see logs/chroot-customize.log)"

# Record what the base system looks like (helps debugging wallpaper/menu issues)
{
  echo "== /etc/skel"; ls -la "$R/etc/skel" 2>&1 | head -40
  echo "== /home"; ls -la "$R/home" 2>&1
  for h in "$R"/home/*; do [ -d "$h" ] || continue; echo "== $h/.icewm"; ls -la "$h/.icewm" 2>&1 | head -40
    [ -f "$h/.icewm/startup" ] && { echo "-- startup (first 40 lines)"; head -40 "$h/.icewm/startup"; }; done
  echo "== wallpapers"; find "$R/usr/share/backgrounds" "$R/usr/share/wallpaper" "$R/usr/local/share/wallpaper" -maxdepth 2 2>/dev/null | head -40
  echo "== keyboard"; cat "$R/etc/default/keyboard" 2>&1
} > "$LOG_DIR/rootfs-inspect.txt" 2>&1 || true

log "Copying Nivora config overlay (wallpaper, tools, shortcuts)"
cp -a "$ROOT_DIR/config/rootfs/." "$R/"
chmod 0755 "$R"/usr/local/bin/nivora-*

# Startup snippet: APPEND to existing IceWM startup files (never replace the antiX one).
# The antiX live user (demo) has a home folder INSIDE the image, so patch /home/* as well as /etc/skel.
SNIP="$ROOT_DIR/config/snippets/startup-snippet.sh"
MARK="# --- Nivora OS additions"
for base in "$R/etc/skel" "$R"/home/*; do
  [ -d "$base" ] || continue
  mkdir -p "$base/.icewm"
  f="$base/.icewm/startup"
  if [ ! -f "$f" ]; then printf '#!/bin/sh\n' > "$f"; fi
  if ! grep -qF "$MARK" "$f"; then printf '\n' >> "$f"; cat "$SNIP" >> "$f"; fi
  chmod 0755 "$f"
  if [ "$base" != "$R/etc/skel" ]; then chown -R --reference="$base" "$base/.icewm"; fi
  log "startup patched: ${f#$R}"
done

# Branding
if [ -f "$R/etc/os-release" ]; then
  sed -i 's/^PRETTY_NAME=.*/PRETTY_NAME="Nivora OS '"$NIVORA_VERSION"' (based on antiX '"$ANTIX_VERSION"')"/' "$R/etc/os-release"
fi

# Package inventory for the release notes
chroot "$R" dpkg-query -W -f='${Package} ${Version}\n' | sort > "$DIST_DIR/PACKAGES.txt"
log "Packages installed in final image: $(wc -l < "$DIST_DIR/PACKAGES.txt")"

# Restore resolv.conf, drop temp files
rm -f "$R/etc/resolv.conf"; [ -e "$R/etc/resolv.conf.orig-antix" ] && mv "$R/etc/resolv.conf.orig-antix" "$R/etc/resolv.conf" || true
rm -rf "$R/tmp/nivora"
log "Customization done"
