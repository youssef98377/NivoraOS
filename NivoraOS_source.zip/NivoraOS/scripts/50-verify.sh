#!/usr/bin/env bash
# Step 5: structural checks on the finished ISO + checksums + build info. Boot is NOT proven here.
source "$(dirname "$0")/lib.sh"
need_cmd xorriso; need_cmd sha256sum
OUT="$DIST_DIR/$NIVORA_ISO_NAME"
[ -s "$OUT" ] || die "ISO missing: $OUT"
REPORT="$DIST_DIR/VERIFY_REPORT.txt"; : > "$REPORT"
pass() { echo "PASS  $*" | tee -a "$REPORT"; }
fail() { echo "FAIL  $*" | tee -a "$REPORT"; FAILED=1; }
FAILED=0

size=$(stat -c %s "$OUT")
[ "$size" -gt 300000000 ] && pass "ISO size is plausible: $size bytes" || fail "ISO too small: $size bytes"

xorriso -indev "$OUT" -find / -type f 2>/dev/null > "$LOG_DIR/new-iso-files.txt" || fail "xorriso cannot read the ISO"
for f in /antiX/linuxfs /antiX/vmlinuz /antiX/initrd.gz; do
  grep -q "'$f'" "$LOG_DIR/new-iso-files.txt" && pass "file present: $f" || fail "file missing: $f"
done
grep -qi "isolinux" "$LOG_DIR/new-iso-files.txt" && pass "isolinux (BIOS bootloader) files present" || fail "no isolinux files found"

report=$(xorriso -indev "$OUT" -report_el_torito plain -report_system_area plain 2>&1 || true)
echo "$report" > "$LOG_DIR/el-torito.txt"
echo "$report" | grep -qi "BIOS" && pass "El Torito BIOS boot entry present" || fail "no El Torito BIOS entry"
echo "$report" | grep -qiE "MBR|isohybrid" && pass "hybrid MBR present (USB-writable as raw image)" || warn "no hybrid MBR reported"
echo "$report" | grep -qi "UEFI" && echo "INFO  UEFI boot entry present (not needed for your PC)" | tee -a "$REPORT"

# squashfs integrity of what is inside the ISO
tmpfs="$WORK_DIR/check-linuxfs"; rm -f "$tmpfs"
xorriso -osirrox on -indev "$OUT" -extract /antiX/linuxfs "$tmpfs" >/dev/null 2>&1
if unsquashfs -s "$tmpfs" >/dev/null 2>&1; then pass "linuxfs inside the ISO is a readable squashfs"; else fail "linuxfs unreadable"; fi
rm -f "$tmpfs"

( cd "$DIST_DIR" && sha256sum "$NIVORA_ISO_NAME" > SHA256SUMS )
pass "SHA256SUMS written"
{
  echo "Nivora OS $NIVORA_VERSION"
  echo "Base: antiX $ANTIX_VERSION (i386, full) sha256 $ANTIX_ISO_SHA256"
  echo "Base signature status: $(cat "$WORK_DIR/download/gpg-status.txt" 2>/dev/null || echo unknown)"
  echo "Built (UTC): $(date -u +%FT%TZ)"
  echo "ISO: $NIVORA_ISO_NAME  size: $size bytes ($(du -h "$OUT" | cut -f1))"
  echo "SHA256: $(cut -d' ' -f1 "$DIST_DIR/SHA256SUMS")"
  echo "Heavy packages purged: $([ "$PURGE_HEAVY" = 1 ] && echo yes || echo no)  (browser from antiX base kept: $([ "$PURGE_HEAVY" = 1 ] && [ "$INCLUDE_BROWSER" = 0 ] && echo no || echo "yes - NOT guaranteed secure on 32-bit"))"
  echo "Boot tested on real hardware: NO"
} > "$DIST_DIR/BUILD_INFO.txt"
[ "$FAILED" -eq 0 ] || die "Verification FAILED, see $REPORT"
log "Structural verification passed (this is NOT a boot test)"
