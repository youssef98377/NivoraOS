#!/usr/bin/env python3
"""Rough, honest screenshot check. It only measures colours; a HUMAN must still look at the images.
Usage: 61-analyze-screenshots.py <screenshots_dir> <output_txt>"""
import glob, os, sys
from PIL import Image

NAVY = (8, 23, 46)      # Nivora wallpaper background
TEAL = (25, 199, 192)   # contour lines

def near(px, ref, tol):
    return all(abs(a - b) <= tol for a, b in zip(px, ref))

def analyze(path):
    im = Image.open(path).convert("RGB")
    im.thumbnail((200, 150))
    w, h = im.size; pix = im.load(); n = w * h
    navy = teal = black = 0
    for y in range(h):
        for x in range(w):
            p = pix[x, y]
            if near(p, NAVY, 22): navy += 1
            if p[0] < 120 and p[1] > 90 and p[2] > 90 and p[1] > p[0] + 40: teal += 1   # turquoise-ish
            if max(p) < 20: black += 1
    navy, teal, black = navy / n, teal / n, black / n
    if navy > 0.30 and teal > 0.0005:
        verdict = "LOOKS LIKE the Nivora wallpaper (desktop probably reached) - still check by eye"
    elif black > 0.9:
        verdict = "almost all black (still booting, or no display output)"
    else:
        verdict = "UNKNOWN (boot menu / other desktop / loading) - look at the image"
    return f"{os.path.basename(path)}: navy={navy:.2f} teal={teal:.3f} black={black:.2f} -> {verdict}"

def main():
    d, out = sys.argv[1], sys.argv[2]
    files = sorted(glob.glob(os.path.join(d, "*.png")) + glob.glob(os.path.join(d, "*.ppm")))
    lines = ["Automatic colour check (NOT a boot test, humans must review the screenshots):"]
    lines += [analyze(f) for f in files] or ["no screenshots found"]
    open(out, "w").write("\n".join(lines) + "\n")
    print("\n".join(lines))

if __name__ == "__main__":
    main()
