#!/usr/bin/env bash
# One command to run the whole pipeline:  sudo ./scripts/build.sh
# Stops at the first failing step. Writes full log to logs/build.log
source "$(dirname "$0")/lib.sh"
need_root
exec > >(tee "$LOG_DIR/build.log") 2>&1
S="$ROOT_DIR/scripts"
"$S/00-check-env.sh"
"$S/10-fetch-verify.sh"
"$S/20-extract.sh"
"$S/30-customize.sh"
"$S/40-repack.sh"
"$S/50-verify.sh"
if [ "${SKIP_QEMU:-0}" != "1" ]; then "$S/60-qemu-boot-test.sh"; fi
log "DONE. Files are in $DIST_DIR"
