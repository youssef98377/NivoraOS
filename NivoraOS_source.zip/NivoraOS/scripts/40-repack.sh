#!/usr/bin/env bash
# Step 4: build the new squashfs and write a NEW ISO that keeps the original boot setup
# (isolinux/BIOS + hybrid MBR + any EFI image) using xorriso "-boot_image any replay".
source "$(dirname "$0")/lib.sh"
need_root; need_cmd mksquashfs; need_cmd xorriso
BASE="$WORK_DIR/download/$ANTIX_ISO_NAME"
R="$WORK_DIR/rootfs"
NEW_FS="$WORK_DIR/linuxfs.new"
OUT="$DIST_DIR/$NIVORA_ISO_NAME"
[ -d "$R/etc" ] || die "rootfs missing"

# Keep the same compression type as antiX so the live kernel can mount it.
COMP="${SQUASH_COMP:-$(awk '/^Compression/ {print $2}' "$LOG_DIR/base-squashfs-info.txt")}"
[ -n "$COMP" ] || die "Could not detect squashfs compression"
log "Building squashfs with compression: $COMP"
rm -f "$NEW_FS"
mksquashfs "$R" "$NEW_FS" -comp "$COMP" -b 1M -noappend -no-progress -e "$R/proc/*" -e "$R/sys/*" 2>&1 | tail -3
[ -s "$NEW_FS" ] || die "New squashfs is empty"
log "New linuxfs: $(du -h "$NEW_FS" | cut -f1)"

# Optional checksum files that antiX ships next to linuxfs
EXTRA=()
if grep -q "'/antiX/linuxfs.md5'" "$LOG_DIR/base-iso-files.txt"; then
  (cd "$WORK_DIR" && md5sum linuxfs.new | sed 's/linuxfs.new/linuxfs/' > linuxfs.md5.new)
  EXTRA+=(-map "$WORK_DIR/linuxfs.md5.new" /antiX/linuxfs.md5)
fi

rm -f "$OUT"
log "Writing $NIVORA_ISO_NAME"
xorriso -indev "$BASE" -outdev "$OUT" \
  -boot_image any replay \
  -map "$NEW_FS" /antiX/linuxfs \
  "${EXTRA[@]}" \
  -commit 2>&1 | tee "$LOG_DIR/xorriso-write.log" | tail -5
[ -s "$OUT" ] || die "ISO was not created"
log "ISO written: $(du -h "$OUT" | cut -f1)"
