#!/usr/bin/env bash
# Step 6 (optional): boot the ISO in QEMU with legacy BIOS (SeaBIOS) and take screenshots every minute.
# A virtual boot does NOT prove sound/display/network on the real Pentium 4 PC.
# The colour analysis is only a hint; a human must look at the screenshots.
source "$(dirname "$0")/lib.sh"
OUT="$DIST_DIR/$NIVORA_ISO_NAME"
SHOTS="$DIST_DIR/qemu-screenshots"; rm -rf "$SHOTS"; mkdir -p "$SHOTS"
command -v qemu-system-i386 >/dev/null || { warn "qemu-system-i386 not installed: boot test SKIPPED"; echo "QEMU boot test: NOT TESTED (qemu missing)" > "$DIST_DIR/QEMU_RESULT.txt"; exit 0; }
[ -s "$OUT" ] || die "ISO missing"
ACCEL=(); [ -w /dev/kvm ] && ACCEL=(-enable-kvm)
log "Booting in QEMU (BIOS mode, 1024 MB RAM, about 8 minutes, screenshot every 60 s)..."
(
  sleep 25; echo "sendkey ret"          # accept default boot-menu entry
  for t in 1 2 3 4 5 6 7; do
    sleep 60; echo "screendump $SHOTS/minute-0$t.ppm"
  done
  sleep 3; echo "quit"
) | qemu-system-i386 "${ACCEL[@]}" -m 1024 -machine pc -vga std -boot d -cdrom "$OUT" \
      -display none -monitor stdio -no-reboot > "$LOG_DIR/qemu.log" 2>&1 || true
n=$(ls "$SHOTS"/*.ppm 2>/dev/null | wc -l)
if command -v convert >/dev/null; then for f in "$SHOTS"/*.ppm; do convert "$f" "${f%.ppm}.png" && rm -f "$f"; done; fi
if [ "$n" -ge 1 ]; then
  python3 "$(dirname "$0")/61-analyze-screenshots.py" "$SHOTS" "$DIST_DIR/SCREENSHOT_ANALYSIS.txt" || warn "analysis failed"
  echo "QEMU boot test: $n screenshots captured. Result = NEEDS HUMAN REVIEW. Real-hardware boot: NOT TESTED." > "$DIST_DIR/QEMU_RESULT.txt"
else
  echo "QEMU boot test: FAIL (no screenshots, see logs/qemu.log). Real-hardware boot: NOT TESTED." > "$DIST_DIR/QEMU_RESULT.txt"
fi
cat "$DIST_DIR/QEMU_RESULT.txt"
