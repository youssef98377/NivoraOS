#!/usr/bin/env bash
# Step 6 (optional): boot the ISO in QEMU with legacy BIOS (SeaBIOS) and take screenshots.
# A virtual boot does NOT prove sound/display/network on the real Pentium 4 PC.
# The script cannot judge the screenshots; a human must look at them.
source "$(dirname "$0")/lib.sh"
OUT="$DIST_DIR/$NIVORA_ISO_NAME"
SHOTS="$DIST_DIR/qemu-screenshots"; mkdir -p "$SHOTS"
command -v qemu-system-i386 >/dev/null || { warn "qemu-system-i386 not installed: boot test SKIPPED"; echo "QEMU boot test: NOT TESTED (qemu missing)" > "$DIST_DIR/QEMU_RESULT.txt"; exit 0; }
[ -s "$OUT" ] || die "ISO missing"
ACCEL=(); [ -w /dev/kvm ] && ACCEL=(-enable-kvm)
log "Booting in QEMU (BIOS mode, 1024 MB RAM, ~4 minutes)..."
(
  sleep 25; echo "sendkey ret"          # accept default boot-menu entry
  sleep 90;  echo "screendump $SHOTS/t115s.ppm"
  sleep 90;  echo "screendump $SHOTS/t205s.ppm"
  sleep 60;  echo "screendump $SHOTS/t265s.ppm"
  sleep 3;   echo "quit"
) | qemu-system-i386 "${ACCEL[@]}" -m 1024 -machine pc -vga std -boot d -cdrom "$OUT" \
      -display none -monitor stdio -no-reboot > "$LOG_DIR/qemu.log" 2>&1 || true
n=$(ls "$SHOTS"/*.ppm 2>/dev/null | wc -l)
if command -v convert >/dev/null; then for f in "$SHOTS"/*.ppm; do convert "$f" "${f%.ppm}.png" && rm -f "$f"; done; fi
if [ "$n" -ge 1 ]; then
  echo "QEMU boot test: screenshots captured ($n). Result = NEEDS HUMAN REVIEW of screenshots. Real-hardware boot: NOT TESTED." > "$DIST_DIR/QEMU_RESULT.txt"
else
  echo "QEMU boot test: FAIL (no screenshots, see logs/qemu.log). Real-hardware boot: NOT TESTED." > "$DIST_DIR/QEMU_RESULT.txt"
fi
cat "$DIST_DIR/QEMU_RESULT.txt"
