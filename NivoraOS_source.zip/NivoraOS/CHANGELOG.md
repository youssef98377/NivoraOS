# Changelog

## 0.1.3 - 2026-10-25
Found by LOOKING at the QEMU screenshots of build 0.1.2: every screenshot showed an admin-password dialog ("dpkg-divert --package antix26-desktop-files --rename --remove /usr/share/applications/claws-mail.desktop") instead of a desktop. Likely cause: build 0.1.0-0.1.2 purged Claws Mail / LibreOffice / Firefox, which breaks antiX's diverted desktop files.
- FIX: nothing is purged from the base image any more (`PURGE_HEAVY=0` in config/antix.env). Consequence: ISO is bigger (about 2.3-2.4 GB, probably over the 2 GiB GitHub Release limit, so the zipped artifact is the reliable download) and a Firefox ESR is probably still in the image. Firefox 32-bit security support is NOT guaranteed after Sept 2026: do not use it for banking/passwords.
- Extra QEMU screenshot of the boot menu at 20 s (`minute-00-bootmenu.png`).
- Findings from rootfs-inspect.log: there is no /home/demo inside the image (the live user is created at boot from /etc/skel), so patching /etc/skel is the right place; antiX wallpapers live in /usr/share/wallpaper.
- UNVERIFIED: whether this fixes the prompt. Needs a new build and a look at the screenshots.

## 0.1.2 - 2026-10-24
- Added help/troubleshooting text inside the OS (menu: Nivora help) and in docs/05_TROUBLESHOOTING_AR.md: boot menu keys, black screen (failsafe / nomodeset xorg=safe / xdrv=vesa), wrong resolution (xorg=1024x768), no sound, no wifi (USB tethering idea), slowness.
- Added `nivora-sound-fix` (unmute all ALSA controls + test sound) and `nivora-help` (opens help in any available editor).
- Added fallback video drivers (fbdev, vesa) as optional packages.
- Boot cheat codes are taken from the antiX documentation (older release docs): NOT verified on antiX 26.1 or on the real PC.

## 0.1.1 - 2026-10-24
Based on the log of the FIRST real GitHub Actions build (run #1: all structural checks PASS, kernel 5.10.256-486-smp, ISO about 2.0 GB).
- Fixed: qpdfview failed (poppler version conflict) -> now installs the first working of mupdf / xpdf / zathura-pdf-mupdf.
- Fixed (safety): the IceWM startup file is now APPENDED to the antiX one instead of replacing it, and is applied to the live user's home inside the image (/home/*), not only /etc/skel.
- Wallpaper is re-applied several times at startup so base scripts cannot overwrite it.
- QEMU test now takes a screenshot every minute for 7 minutes and runs a colour check (hint only, humans must look).
- Workflow: small artifact `nivora-screenshots-and-reports` (a few MB) + ISO published as a Release (direct .iso download) + zipped ISO artifact as backup.
- Logs `rootfs-inspect.txt` record what the base desktop looks like, to help the next fix.
- NOT changed on purpose: boot menu text still says antiX (it is inside a compiled graphical menu; editing it risks an unbootable image).

## 0.1.0 - 2026-10-24 (source only, no ISO built yet)
- Base pinned to antiX 26.1 i386 full (official, released 2026-09-29), SHA-256 pinned from the official download page.
- Build pipeline: fetch+verify, extract, chroot customize, repack (BIOS boot preserved), verify, optional QEMU boot test.
- GitHub Actions workflow with manual start.
- Nivora overlay: wallpaper, IceWM startup (US/Arabic keyboard, wallpaper), hardware check tool, survey calculator (12 unit tests pass), study folders, ArcMap/Surfer notes.
- Firefox removed by default (32-bit Firefox security support ended for ESR 140 after September 2026 at the earliest guarantee).
