# Changelog

## 0.1.1 - 2026-10-24
Based on the log of the FIRST real GitHub Actions build (run #1: all structural checks PASS, kernel 5.10.256-486-smp, ISO about 2.0 GB).
- Fixed: qpdfview failed (poppler version conflict) -> now installs the first working of mupdf / xpdf / zathura-pdf-mupdf.
- Fixed (safety): the IceWM startup file is now APPENDED to the antiX one instead of replacing it, and is applied to the live user's home inside the image (/home/*), not only /etc/skel.
- Wallpaper is re-applied several times at startup so base scripts cannot overwrite it.
- QEMU test now takes a screenshot every minute for 7 minutes and runs a colour check (hint only, humans must look).
- Workflow: small artifact `nivora-screenshots-and-reports` (a few MB) + ISO published as a Release (direct .iso download) + zipped ISO artifact as backup.
- Logs `rootfs-inspect.txt` record what the base desktop looks like, to help the next fix.
- NOT changed on purpose: boot menu text still says antiX (it is inside a compiled graphical menu; editing it risks an unbootable image).

## 0.1.0 - 2026-10-24 (source only, no ISO built yet)
- Base pinned to antiX 26.1 i386 full (official, released 2026-09-29), SHA-256 pinned from the official download page.
- Build pipeline: fetch+verify, extract, chroot customize, repack (BIOS boot preserved), verify, optional QEMU boot test.
- GitHub Actions workflow with manual start.
- Nivora overlay: wallpaper, IceWM startup (US/Arabic keyboard, wallpaper), hardware check tool, survey calculator (12 unit tests pass), study folders, ArcMap/Surfer notes.
- Firefox removed by default (32-bit Firefox security support ended for ESR 140 after September 2026 at the earliest guarantee).
