# Changelog

## 0.1.0 - 2026-10-24 (source only, no ISO built yet)
- Base pinned to antiX 26.1 i386 full (official, released 2026-09-29), SHA-256 pinned from the official download page.
- Build pipeline: fetch+verify, extract, chroot customize, repack (BIOS boot preserved), verify, optional QEMU boot test.
- GitHub Actions workflow with manual start.
- Nivora overlay: wallpaper, IceWM startup (US/Arabic keyboard, wallpaper), hardware check tool, survey calculator (12 unit tests pass), study folders, ArcMap/Surfer notes.
- Firefox removed by default (32-bit Firefox security support ended for ESR 140 after September 2026 at the earliest guarantee).
