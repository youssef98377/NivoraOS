# Licenses and sources

## Base system (downloaded at build time, NOT stored in this repo)
- antiX Linux 26.1 i386 full - https://antixlinux.com/ - mostly GPL and other free licenses; contains Debian 13 packages. Each package keeps its own license (see /usr/share/doc/*/copyright inside the image).
- SHA-256 pin source: https://antixlinux.com/download/ and https://sourceforge.net/projects/antix-linux/files/Final/antiX-26.1/
- Release notes: https://antixlinux.com/antix-26-1-released/

## Added/removed by Nivora
- Added from Debian/antiX repos: see config/packages-required.txt and config/packages-optional.txt (final list is written to dist/PACKAGES.txt after a build).
- Removed: LibreOffice, Claws Mail, Firefox ESR (see config/packages-remove*.txt).

## Files made for this project
- Scripts, docs, calculator, wallpaper: created for Nivora OS. Suggested license: MIT (change if you prefer).
- docs/reference/Nivora_OS_Desktop_Concept.png: concept art from the project pack. It is a mock-up, NOT a screenshot of a working desktop.

## Not included (on purpose)
- No Windows files or drivers, no ReactOS, no ArcMap, no Golden Software Surfer, no Wine.
