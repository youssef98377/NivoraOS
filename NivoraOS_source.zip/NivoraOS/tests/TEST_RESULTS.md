# Test results (honest status)

Status when this source pack was created (2026-10-24). The creating environment had NO internet and NO xorriso/mksquashfs/QEMU, so no ISO could be built.

| Test | Result | Evidence / note |
|---|---|---|
| Bash syntax of all scripts (`bash -n`) | PASS | ran in creation environment |
| Calculator unit tests (12 checks) | PASS | `python3 tests/test_survey_calc.py` |
| Official antiX 26.1 i386 SHA-256 pinned | PINNED, NOT VERIFIED BY DOWNLOAD | value read from antiX download page + SourceForge; file not downloaded yet |
| Official GPG signature check | NOT TESTED | needs antiX public key (`ANTIX_GPG_KEYRING`) |
| Download of base ISO | NOT TESTED | no network in creation environment |
| Chroot customization (packages, overlay) | NOT TESTED | first GitHub Actions run will show |
| ISO repack with BIOS boot preserved | NOT TESTED | |
| ISO structural verification (`50-verify.sh`) | NOT TESTED | |
| Boot in QEMU (BIOS mode) | NOT TESTED | |
| Real PC: boot from USB without touching disk | NOT TESTED | |
| Real PC: desktop 800x600 / 1024x768 | NOT TESTED | |
| Real PC: keyboard / mouse | NOT TESTED | |
| Real PC: sound (ALC260?) | NOT TESTED | |
| Real PC: network wired / wireless | NOT TESTED | |
| Real PC: USB ports | NOT TESTED | |
| Real PC: shutdown / restart | NOT TESTED | |
| Arabic display + Alt+Shift layout switch | NOT TESTED | |
| ArcMap on current Windows 7 | NOT TESTED | user to test on Windows |
| Surfer on current Windows 7 | NOT TESTED | user to test on Windows |
| Wine / ReactOS with ArcMap or Surfer | NOT TESTED | not claimed |
