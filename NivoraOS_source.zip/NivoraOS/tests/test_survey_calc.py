"""Run: python3 tests/test_survey_calc.py   (no extra libraries needed)"""
import importlib.machinery, importlib.util, os, sys

path = os.path.join(os.path.dirname(__file__), "..", "config", "rootfs", "usr", "local", "bin", "nivora-survey-calc")
loader = importlib.machinery.SourceFileLoader("calc", path)
spec = importlib.util.spec_from_loader("calc", loader)
calc = importlib.util.module_from_spec(spec); loader.exec_module(calc)

def close(a, b, t=1e-6): return abs(a - b) < t
fails = 0
def check(name, cond):
    global fails
    print(("PASS  " if cond else "FAIL  ") + name)
    if not cond: fails += 1

check("distance 3-4-5", close(calc.distance((0, 0), (3, 4)), 5))
check("azimuth east = 90", close(calc.azimuth((0, 0), (10, 0)), 90))
check("azimuth north = 0", close(calc.azimuth((0, 0), (0, 10)), 0))
check("azimuth west = 270", close(calc.azimuth((0, 0), (-10, 0)), 270))
check("azimuth south = 180", close(calc.azimuth((0, 0), (0, -10)), 180))
check("area square 10x10 = 100", close(calc.polygon_area([(0, 0), (10, 0), (10, 10), (0, 10)]), 100))
check("area right triangle = 6", close(calc.polygon_area([(0, 0), (4, 0), (0, 3)]), 6))
check("area orientation independent", close(calc.polygon_area([(0, 0), (0, 10), (10, 10), (10, 0)]), 100))
check("dms 30 15 36 -> 30.26", close(calc.dms_to_decimal(30, 15, 36), 30.26))
d, m, s = calc.decimal_to_dms(30.26)
check("decimal 30.26 -> 30 15 36", (d, m) == (30, 15) and close(s, 36, 1e-3))
fed, q, s = calc.m2_to_feddan(4200.833)
check("4200.833 m2 = 1 feddan", fed == 1 and q == 0 and s < 0.01)
try:
    calc.polygon_area([(0, 0), (1, 1)]); check("area rejects <3 points", False)
except ValueError:
    check("area rejects <3 points", True)
sys.exit(1 if fails else 0)
