# Nivora OS — مشروع المصدر (الإصدار 0.1.0)

## الحالة بصراحة
- ✅ جاهز: سكربتات بناء، ملف GitHub Actions، أدوات النظام، الخلفية، التوثيق.
- ❌ **لسه ما اتبنتش ISO ولا اتجرّبت على أي جهاز.** البيئة اللي اتكتب فيها المشروع مكانش فيها إنترنت ولا أدوات بناء ISO.
- النظام مبني على **antiX 26.1 (32-bit)** الرسمي، مش على نواة ويندوز.

## إزاي تبني الـISO من الموبايل (من غير برمجة)
1. اعمل حساب على github.com وأنشئ Repository جديد (Private أحسن).
2. ارفع الملف `NivoraOS_source.zip` (بدون فك) من **Add file → Upload files**.
3. **Add file → Create new file**، اكتب الاسم بالظبط: `.github/workflows/build-iso.yml` وانسخ جواه محتوى ملف `build-iso.yml` اللي معاك، وبعدين Commit.
4. افتح تبويب **Actions** → **Build Nivora OS ISO** → **Run workflow**.
5. استنى (ساعة تقريبًا أو أكتر). لو نجح هتلاقي في آخر الصفحة **Artifacts**: `nivora-os-iso` (فيها الـISO و`SHA256SUMS`) و`nivora-build-logs`.
6. **لو فشل** (متوقع في أول مرة لأن البناء ما اتجرّبش): نزّل `nivora-build-logs` وابعتلي الملف `build.log` وأنا أصلّحه.

## بعد ما الـISO تطلع
اتبع `docs/02_USB_AND_BOOT_AR.md` (Rufus + قايمة الإقلاع). **مش هتثبّت حاجة على الهارد.** ويندوز 7 يفضل زي ما هو.

## محتويات المجلد
`scripts/` البناء · `config/` الإعدادات والأدوات · `docs/` التوثيق · `tests/` الاختبارات ونتائجها · `dist/` الناتج (فاضي لحد ما البناء ينجح) · `LICENSES_AND_SOURCES.md` المصادر والتراخيص.

## بناء محلي (لو عندك لينكس)
`sudo apt-get install -y curl xorriso squashfs-tools gpgv qemu-system-x86 imagemagick` ثم `sudo ./scripts/build.sh` (محتاج 14 GB فاضيين وإنترنت).

## قيود لازم تعرفها
ArcMap/Surfer مش بيشتغلوا على لينكس تلقائيًا (استخدم ويندوز 7). مفيش متصفح مضمون الأمان للمعالج ده. الصوت والشاشة والعربي محتاجين تجربة حقيقية على جهازك.
