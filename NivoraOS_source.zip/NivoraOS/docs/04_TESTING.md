# Test plan (record PASS / FAIL / NOT TESTED with evidence)

See tests/TEST_RESULTS.md for the current honest status. Rules:
- QEMU boot = virtual only. It never proves sound, graphics or network on the real PC.
- "PASS" on real hardware needs: booted from USB, internal disk untouched, Windows 7 still boots afterwards.
- Never write "tested on Pentium 4" unless that really happened.

Real-hardware checklist: boot Live (not Installer); desktop appears; 800x600 and 1024x768; keyboard; mouse; sound (play a local file); wired network; USB read/write on another stick; Arabic text display; Alt+Shift layout switch; shutdown and restart; Windows 7 still OK afterwards.
