# --- Nivora OS additions (appended to the IceWM startup file) ---
# 1) keyboard: US + Arabic, Alt+Shift to switch
setxkbmap -layout us,ara -option grp:alt_shift_toggle 2>/dev/null &
# 2) wallpaper: re-apply a few times so the base desktop scripts cannot overwrite it
(
  for delay in 4 8 15 30; do
    sleep "$delay"
    if command -v feh >/dev/null 2>&1 && [ -f /usr/share/nivora/wallpaper.png ]; then
      feh --bg-fill /usr/share/nivora/wallpaper.png
    else
      xsetroot -solid '#08172E'
    fi
  done
) &
# --- end Nivora OS additions ---
