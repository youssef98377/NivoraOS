# Test results (honest status)

Status after GitHub Actions build run #1 (2026-10-24). Version 0.1.1 has NOT been built yet; the table describes run #1 of 0.1.0 plus what is untested.

| Test | Result | Evidence / note |
|---|---|---|
| Bash syntax of all scripts (`bash -n`) | PASS | ran in creation environment |
| Calculator unit tests (12 checks) | PASS | `python3 tests/test_survey_calc.py` |
| Official antiX 26.1 i386 SHA-256 pinned | PINNED, NOT VERIFIED BY DOWNLOAD | value read from antiX download page + SourceForge; file not downloaded yet |
| Official GPG signature check | NOT TESTED | needs antiX public key (`ANTIX_GPG_KEYRING`) |
| Download of base ISO + SHA-256 match | PASS | GitHub Actions run #1 log (sha256 6ec6f652...57fbc verified) |
| Chroot customization (packages, overlay) | PASS with 1 warning | run #1: qpdfview not installable (fixed in 0.1.1) |
| ISO repack with BIOS boot preserved | PASS | run #1: El Torito BIOS + hybrid MBR present |
| ISO structural verification (`50-verify.sh`) | PASS | run #1: all checks PASS (size 2,118,057,984 bytes) |
| Boot in QEMU (BIOS mode), builds 0.1.2 and 0.1.3 | FAIL (no desktop) | all 7 screenshots show an admin-password dialog about dpkg-divert claws-mail.desktop; 0.1.3 failed again with inxi-gui.desktop (inxi install removed antiX packages); fix in 0.1.4 NOT yet re-tested |
| Real PC: boot from USB without touching disk | NOT TESTED | |
| Real PC: desktop 800x600 / 1024x768 | NOT TESTED | |
| Real PC: keyboard / mouse | NOT TESTED | |
| Real PC: sound (ALC260?) | NOT TESTED | |
| Real PC: network wired / wireless | NOT TESTED | |
| Real PC: USB ports | NOT TESTED | |
| Real PC: shutdown / restart | NOT TESTED | |
| Arabic display + Alt+Shift layout switch | NOT TESTED | |
| ArcMap on current Windows 7 | NOT TESTED | user to test on Windows |
| Surfer on current Windows 7 | NOT TESTED | user to test on Windows |
| Wine / ReactOS with ArcMap or Surfer | NOT TESTED | not claimed |
